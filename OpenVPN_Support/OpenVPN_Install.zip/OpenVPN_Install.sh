#!/bin/bash

# Update system package list
echo "Updating system packages..."
sudo apt update && sudo apt upgrade -y

# Install OpenVPN
echo "Installing OpenVPN..."
sudo apt install -y openvpn

# Enable and start OpenVPN service
echo "Starting OpenVPN service..."
sudo systemctl enable openvpn
sudo systemctl start openvpn

# Verify installation
echo "Checking OpenVPN status..."
sudo systemctl status openvpn --no-pager

echo "OpenVPN installation completed successfully!"

